﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.IO;
using System.Data;

public partial class Default2 : System.Web.UI.Page
{
    string conString = ConfigurationManager.ConnectionStrings["myconnection"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnRegistrations_Click(object sender, EventArgs e)
    {
        if (empprofile.PostedFile!=null && empbiodata.PostedFile!=null)
        {
            
                string profile = empprofile.FileName.ToString();
                empprofile.PostedFile.SaveAs(Server.MapPath("~/Employee/profile/") + profile);
                string biodata = empbiodata.FileName.ToString();
                empbiodata.PostedFile.SaveAs(Server.MapPath("~/Employee/biodata/") + biodata);

                SqlConnection con = new SqlConnection(conString);

                SqlCommand cmd = new SqlCommand("sp_EmpRegistration", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmpName", SqlDbType.VarChar).Value = empname.Text.Trim();
                cmd.Parameters.AddWithValue("@EmpAddress", SqlDbType.VarChar).Value = empaddress.Text.Trim();
                cmd.Parameters.AddWithValue("@EmpProfile", SqlDbType.VarChar).Value = "Employee/profile/"+profile;
                cmd.Parameters.AddWithValue("@EmpBiodata", SqlDbType.VarChar).Value = "Employee/biodata/" + biodata;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                Response.Redirect("ListOfEmployee.aspx");

            
           
        }
    }
}