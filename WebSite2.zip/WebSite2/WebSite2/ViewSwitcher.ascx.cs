﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.AspNet.FriendlyUrls;
using Microsoft.AspNet.FriendlyUrls.Resolvers;

public partial class ViewSwitcher : System.Web.UI.UserControl
{
    protected string CurrentView { get; private set; }

    protected string AlternateView { get; private set; }

    protected string SwitchUrl { get; private set; }

    protected void Page_Load(object sender, EventArgs e)
    {
        // Determine current view
        var isMobile = WebFormsFriendlyUrlResolver.IsMobileView(new HttpContextWrapper(Context));
        CurrentView = isMobile ? "Mobile" : "Desktop";

        // Determine alternate view
        AlternateView = isMobile ? "Desktop" : "Mobile";

        // Create switch URL from the route, e.g. ~/__FriendlyUrls_SwitchView/Mobile?ReturnUrl=/Page
        var url = GetRouteUrl("AspNet.FriendlyUrls.SwitchView", new { view = AlternateView });
        url += "?ReturnUrl=" + HttpUtility.UrlEncode(Request.RawUrl);
        SwitchUrl = url;
    }
}